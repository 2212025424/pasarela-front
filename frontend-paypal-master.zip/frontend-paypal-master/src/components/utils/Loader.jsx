const Loader = () => {
  return (
    <div className='text-center max-w-6xl mx-auto py-4'>
      <p>Cargando</p>
    </div>
  )
}

export default Loader