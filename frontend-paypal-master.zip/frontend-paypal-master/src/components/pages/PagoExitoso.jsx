const PagoExitoso = () => {
  return (
    <div className="text-center py-8">
      <h1 className="text-6xl">Pago exitoso!!</h1>
      <p>Tu pago ha sido procesado correctamente</p>
    </div>
  )
}
export default PagoExitoso